package odev3Bounus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.openqa.selenium.WebElement;

public class Product {
    /**
     * WebElement name;
     * double price;
     * WebElement addToCart
     * instance variable'lari tanimlidir
     * lombok'un @Getter, @Setter, @ToString ve @AllArgsConstructor annotationslarini kullanir
     */
}
